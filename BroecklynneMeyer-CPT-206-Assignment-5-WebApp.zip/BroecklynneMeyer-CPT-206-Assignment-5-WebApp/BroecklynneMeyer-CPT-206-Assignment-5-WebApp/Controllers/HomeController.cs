﻿using BroecklynneMeyer_CPT_206_Assignment_5_WebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace BroecklynneMeyer_CPT_206_Assignment_5_WebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory clientFactory;//field to store the HTTP client factory

        public HomeController(ILogger<HomeController> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            clientFactory = httpClientFactory;//set field for http client factory
        }

        public async Task<IActionResult> Students()
        {
            string uri;
            
            ViewData["Title"] = "All Customers Worldwide";
            uri = "api/students/";
           
                
  
            HttpClient client = clientFactory.CreateClient(name: "StudentProfile.WebApi");
            HttpRequestMessage request = new(method: HttpMethod.Get, requestUri: uri);
            HttpResponseMessage response = await client.SendAsync(request);
            IEnumerable<Student>? model = await response.Content.ReadFromJsonAsync<IEnumerable<Student>>();
            return View(model);
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
